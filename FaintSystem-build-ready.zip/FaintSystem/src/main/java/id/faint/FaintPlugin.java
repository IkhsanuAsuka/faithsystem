package id.faint;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class FaintPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {

    private FaintManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new FaintManager(this);
        getServer().getPluginManager().registerEvents(new FaintListener(this, manager), this);
        manager.start();

        for (String name : new String[]{"setspawndead", "setlife"}) {
            PluginCommand cmd = getCommand(name);
            if (cmd != null) {
                cmd.setExecutor(this);
                cmd.setTabCompleter(this);
            }
        }
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.shutdown();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase();

        if (name.equals("setspawndead")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(Component.text("Command ini hanya untuk player.", NamedTextColor.RED));
                return true;
            }
            manager.setDeadSpawn(p.getLocation());
            p.sendMessage(Component.text("Lokasi tunggu orang mati sudah disimpan di posisimu.", NamedTextColor.GREEN));
            return true;
        }

        if (name.equals("setlife")) {
            if (args.length < 1) {
                sender.sendMessage(Component.text("Pakai: /setlife <player>", NamedTextColor.RED));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target != null) {
                if (!manager.isDead(target)) {
                    sender.sendMessage(Component.text(target.getName() + " sedang tidak mati.", NamedTextColor.RED));
                    return true;
                }
                manager.instantRevive(target);
                sender.sendMessage(Component.text(target.getName() + " dihidupkan kembali.", NamedTextColor.GREEN));
                return true;
            }
            OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (off != null && manager.isDead(off.getUniqueId())) {
                manager.reviveOnJoin(off.getUniqueId());
                sender.sendMessage(Component.text(args[0] + " offline, akan dihidupkan saat login.", NamedTextColor.YELLOW));
                return true;
            }
            sender.sendMessage(Component.text("Player tidak ditemukan atau sedang tidak mati.", NamedTextColor.RED));
            return true;
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (command.getName().equalsIgnoreCase("setlife") && args.length == 1) {
            String prefix = args[0].toLowerCase();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (manager.isDead(p) && p.getName().toLowerCase().startsWith(prefix)) out.add(p.getName());
            }
        }
        return out;
    }
}
