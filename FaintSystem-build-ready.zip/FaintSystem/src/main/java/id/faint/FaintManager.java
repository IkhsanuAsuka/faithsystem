package id.faint;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class FaintManager {

    enum Type { FAINT, REVIVE }

    /** Status "mati": kapan boleh hidup lagi + gamemode sebelum mati. */
    record DeadState(long until, GameMode mode) {}

    private static final int FAINT_TICKS = 140;
    private static final int REVIVE_TICKS = 110;

    private final FaintPlugin plugin;
    private final File dataFile;

    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, DeadState> dead = new HashMap<>();
    private final Map<UUID, List<Entity>> corpses = new HashMap<>();
    private Location deadSpawn;
    private BukkitTask ticker;

    public FaintManager(FaintPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        loadData();
    }

    /* ================= lifecycle ================= */

    public void start() {
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tickWaiting, 20L, 20L);
    }

    public void shutdown() {
        if (ticker != null) ticker.cancel();
        for (Session s : new ArrayList<>(sessions.values())) s.cleanup();
        sessions.clear();
        for (UUID id : new ArrayList<>(corpses.keySet())) removeCorpse(id);
        saveData();
    }

    /* ================= config helpers ================= */

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private long waitMs() {
        return Math.max(0L, cfg().getLong("wait-minutes", 30L)) * 60_000L;
    }

    public int waitRadius() {
        return cfg().getInt("waiting-radius", 40);
    }

    public List<String> allowedCommands() {
        List<String> out = new ArrayList<>();
        for (String s : cfg().getStringList("allowed-commands")) {
            out.add(s.startsWith("/") ? s.substring(1) : s);
        }
        return out;
    }

    private GameMode waitingMode() {
        try {
            return GameMode.valueOf(cfg().getString("waiting-gamemode", "ADVENTURE").toUpperCase());
        } catch (IllegalArgumentException ex) {
            return GameMode.ADVENTURE;
        }
    }

    private boolean faceUp() {
        return !"SWIMMING".equalsIgnoreCase(cfg().getString("faint-pose", "SLEEPING"));
    }

    private Material material(String path, Material def) {
        Material m = Material.matchMaterial(cfg().getString(path, def.name()));
        return (m != null && m.isBlock()) ? m : def;
    }

    /* ================= state queries ================= */

    public boolean isDead(Player p) {
        return dead.containsKey(p.getUniqueId());
    }

    public boolean isDead(UUID id) {
        return dead.containsKey(id);
    }

    public boolean isWaiting(Player p) {
        return dead.containsKey(p.getUniqueId()) && !sessions.containsKey(p.getUniqueId());
    }

    public boolean isRestricted(Player p) {
        UUID id = p.getUniqueId();
        return sessions.containsKey(id) || dead.containsKey(id);
    }

    public Location deadSpawn() {
        return deadSpawn == null ? null : deadSpawn.clone();
    }

    public void setDeadSpawn(Location loc) {
        this.deadSpawn = loc.clone();
        saveData();
    }

    /* ================= persistence ================= */

    private void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection sp = y.getConfigurationSection("spawn");
        if (sp != null) {
            World w = Bukkit.getWorld(sp.getString("world", ""));
            if (w != null) {
                deadSpawn = new Location(w, sp.getDouble("x"), sp.getDouble("y"), sp.getDouble("z"),
                        (float) sp.getDouble("yaw"), (float) sp.getDouble("pitch"));
            }
        }
        ConfigurationSection ds = y.getConfigurationSection("dead");
        if (ds != null) {
            for (String key : ds.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(key);
                    long until = ds.getLong(key + ".until");
                    GameMode gm = GameMode.valueOf(ds.getString(key + ".mode", "SURVIVAL"));
                    dead.put(id, new DeadState(until, gm));
                } catch (IllegalArgumentException ignored) {
                    // data rusak: lewati
                }
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        if (deadSpawn != null && deadSpawn.getWorld() != null) {
            y.set("spawn.world", deadSpawn.getWorld().getName());
            y.set("spawn.x", deadSpawn.getX());
            y.set("spawn.y", deadSpawn.getY());
            y.set("spawn.z", deadSpawn.getZ());
            y.set("spawn.yaw", deadSpawn.getYaw());
            y.set("spawn.pitch", deadSpawn.getPitch());
        }
        for (Map.Entry<UUID, DeadState> e : dead.entrySet()) {
            y.set("dead." + e.getKey() + ".until", e.getValue().until());
            y.set("dead." + e.getKey() + ".mode", e.getValue().mode().name());
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Gagal menyimpan data.yml: " + ex.getMessage());
        }
    }

    /* ================= alur utama ================= */

    /** Mulai sinematik pingsan (dipanggil saat damage mematikan). */
    public void startFaint(Player p) {
        UUID id = p.getUniqueId();
        if (sessions.containsKey(id) || dead.containsKey(id)) return;

        if (cfg().getBoolean("drop-inventory-on-faint", false)) dropInventory(p);

        for (PotionEffect pe : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(pe.getType());
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setFireTicks(0);

        GameMode before = p.getGameMode();
        if (before == GameMode.SPECTATOR) before = GameMode.SURVIVAL;
        dead.put(id, new DeadState(System.currentTimeMillis() + waitMs(), before));
        saveData();

        Session s = new Session(p, Type.FAINT, p.getLocation());
        sessions.put(id, s);
        s.start();
    }

    /** Jalur cadangan: player mati beneran (tanpa sinematik). */
    public void markDeath(Player p) {
        UUID id = p.getUniqueId();
        if (dead.containsKey(id)) return;
        GameMode before = p.getGameMode();
        if (before == GameMode.SPECTATOR) before = GameMode.SURVIVAL;
        dead.put(id, new DeadState(System.currentTimeMillis() + waitMs(), before));
        saveData();
    }

    public void onJoin(Player p) {
        DeadState st = dead.get(p.getUniqueId());
        if (st == null) return;
        if (System.currentTimeMillis() >= st.until()) {
            startRevive(p);
        } else {
            reapplyWaiting(p);
        }
    }

    public void onQuit(Player p) {
        abortSession(p);
    }

    /** Taruh player di tempat tunggu dengan gamemode tunggu. */
    public void reapplyWaiting(Player p) {
        if (sessions.containsKey(p.getUniqueId())) return;
        Location target = deadSpawn != null ? deadSpawn.clone() : p.getWorld().getSpawnLocation();
        p.teleport(target);
        p.setGameMode(waitingMode());
        p.setFallDistance(0f);
        p.setFireTicks(0);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
    }

    public void startRevive(Player p) {
        UUID id = p.getUniqueId();
        if (sessions.containsKey(id) || !dead.containsKey(id)) return;
        Session s = new Session(p, Type.REVIVE, pickReviveLocation());
        sessions.put(id, s);
        s.start();
    }

    /** /setlife: hidup langsung di lokasi acak, tanpa sinematik. */
    public void instantRevive(Player p) {
        abortSession(p);
        if (!dead.containsKey(p.getUniqueId())) return;
        completeRevive(p, pickReviveLocation());
    }

    /** /setlife untuk player offline: hidup begitu login. */
    public void reviveOnJoin(UUID id) {
        DeadState st = dead.get(id);
        if (st == null) return;
        dead.put(id, new DeadState(0L, st.mode()));
        saveData();
    }

    public void abortSession(Player p) {
        Session s = sessions.remove(p.getUniqueId());
        if (s != null) s.cleanup();
    }

    private void completeRevive(Player p, Location loc) {
        UUID id = p.getUniqueId();
        DeadState st = dead.remove(id);
        saveData();
        removeCorpse(id);

        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.teleport(loc);
        GameMode gm = (st == null || st.mode() == GameMode.SPECTATOR) ? GameMode.SURVIVAL : st.mode();
        p.setGameMode(gm);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(10f);
        p.setFallDistance(0f);
        p.setFireTicks(0);
        p.getWorld().playSound(loc, Sound.ITEM_TOTEM_USE, 0.8f, 1.2f);
        p.showTitle(Title.title(
                Component.text("HIDUP KEMBALI", NamedTextColor.GREEN, TextDecoration.BOLD),
                Component.text("Kamu bangkit di tempat yang asing...", NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofSeconds(1))));
    }

    private void dropInventory(Player p) {
        Location loc = p.getLocation();
        for (ItemStack it : p.getInventory().getContents()) {
            if (it != null && it.getType() != Material.AIR) p.getWorld().dropItemNaturally(loc, it);
        }
        p.getInventory().clear();
    }

    /* ================= timer menunggu ================= */

    private void tickWaiting() {
        long now = System.currentTimeMillis();
        for (UUID id : new ArrayList<>(dead.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || sessions.containsKey(id)) continue;
            DeadState st = dead.get(id);
            if (st == null) continue;
            long left = st.until() - now;
            if (left <= 0) {
                startRevive(p);
            } else {
                long sec = (left + 999) / 1000;
                String t = String.format("%02d:%02d", sec / 60, sec % 60);
                p.sendActionBar(Component.text("Hidup kembali dalam " + t, NamedTextColor.GRAY));
            }
        }
    }

    /* ================= lokasi ================= */

    private Location pickReviveLocation() {
        FileConfiguration c = cfg();
        String wn = c.getString("revive.world", "");
        World w = (wn == null || wn.isBlank()) ? Bukkit.getWorlds().get(0) : Bukkit.getWorld(wn);
        if (w == null) w = Bukkit.getWorlds().get(0);

        Location sp = w.getSpawnLocation();
        int min = Math.max(0, c.getInt("revive.min-radius", 200));
        int max = Math.max(min + 1, c.getInt("revive.max-radius", 3000));
        ThreadLocalRandom r = ThreadLocalRandom.current();

        if (w.getEnvironment() == World.Environment.NORMAL) {
            for (int i = 0; i < 30; i++) {
                double ang = r.nextDouble(0, Math.PI * 2);
                double dist = Math.sqrt(r.nextDouble((double) min * min, (double) max * max));
                int x = sp.getBlockX() + (int) Math.round(Math.cos(ang) * dist);
                int z = sp.getBlockZ() + (int) Math.round(Math.sin(ang) * dist);
                if (!w.getWorldBorder().isInside(new Location(w, x + 0.5, 64, z + 0.5))) continue;

                Block b = w.getHighestBlockAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
                Material m = b.getType();
                if (b.isLiquid() || m.isAir() || m == Material.LAVA || m == Material.MAGMA_BLOCK
                        || m == Material.CACTUS || m == Material.FIRE || m == Material.POWDER_SNOW) continue;

                return new Location(w, x + 0.5, b.getY() + 1.0, z + 0.5, r.nextFloat() * 360f, 0f);
            }
        }
        Location fb = sp.clone();
        fb.setY(w.getHighestBlockYAt(fb) + 1.0);
        return fb;
    }

    private Location findGround(Location l) {
        World w = l.getWorld();
        RayTraceResult r = w.rayTraceBlocks(l.clone().add(0, 0.6, 0), new Vector(0, -1, 0), 24,
                FluidCollisionMode.NEVER, true);
        double y = (r != null && r.getHitPosition() != null) ? r.getHitPosition().getY() : l.getY();
        return new Location(w, l.getX(), y + 0.02, l.getZ(), l.getYaw(), 0f);
    }

    /* ================= badan (display entity) ================= */

    private BlockDisplay box(Location g, double dx, double dz,
                             double a0, double a1, double s0, double s1,
                             double h0, double h1, BlockData data) {
        double sx = -dz, sz = dx;
        double x0 = g.getX() + dx * a0 + sx * s0, x1 = g.getX() + dx * a1 + sx * s1;
        double z0 = g.getZ() + dz * a0 + sz * s0, z1 = g.getZ() + dz * a1 + sz * s1;
        final double minX = Math.min(x0, x1), maxX = Math.max(x0, x1);
        final double minZ = Math.min(z0, z1), maxZ = Math.max(z0, z1);

        Location at = g.clone();
        at.setYaw(0f);
        at.setPitch(0f);
        return g.getWorld().spawn(at, BlockDisplay.class, bd -> {
            bd.setBlock(data);
            bd.setBrightness(new Display.Brightness(15, 15));
            bd.setPersistent(false);
            bd.setTransformation(new Transformation(
                    new Vector3f((float) (minX - g.getX()), (float) h0, (float) (minZ - g.getZ())),
                    new AxisAngle4f(),
                    new Vector3f((float) (maxX - minX), (float) (h1 - h0), (float) (maxZ - minZ)),
                    new AxisAngle4f()));
        });
    }

    private List<Entity> spawnBody(Player p, Location g, float yaw) {
        World w = g.getWorld();
        boolean up = faceUp();
        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);       // arah hadap sesuai yaw
        double dx = Math.round(up ? -fx : fx);                 // arah kepala (sumbu lurus)
        double dz = Math.round(up ? -fz : fz);

        BlockData shirt = material("body.shirt", Material.CYAN_CONCRETE).createBlockData();
        BlockData pants = material("body.pants", Material.BLUE_CONCRETE).createBlockData();

        List<Entity> out = new ArrayList<>();
        out.add(box(g, dx, dz, -1.0, -0.25, -0.25, 0.25, 0.0, 0.25, pants));   // kaki
        out.add(box(g, dx, dz, -0.25, 0.5, -0.25, 0.25, 0.0, 0.25, shirt));    // badan
        out.add(box(g, dx, dz, -0.25, 0.5, -0.5, -0.25, 0.0, 0.25, shirt));    // tangan kiri
        out.add(box(g, dx, dz, -0.25, 0.5, 0.25, 0.5, 0.0, 0.25, shirt));      // tangan kanan

        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(p);
            skull.setItemMeta(meta);
        }
        final float tilt = (float) (up ? -Math.PI / 2 : Math.PI / 2);
        final float hs = (float) cfg().getDouble("body.head-scale", 1.0);
        Location hl = new Location(w, g.getX() + dx * 0.75, g.getY() + 0.25, g.getZ() + dz * 0.75, yaw, 0f);
        out.add(w.spawn(hl, ItemDisplay.class, d -> {
            d.setItemStack(skull);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setPersistent(false);
            d.setTransformation(new Transformation(
                    new Vector3f(),
                    new AxisAngle4f(tilt, 1f, 0f, 0f),
                    new Vector3f(hs, hs, hs),
                    new AxisAngle4f()));
        }));
        return out;
    }

    private void removeAll(List<Entity> list) {
        if (list == null) return;
        for (Entity e : list) {
            if (e != null && e.isValid()) e.remove();
        }
    }

    private void removeCorpse(UUID id) {
        removeAll(corpses.remove(id));
    }

    /* ================= util sinematik ================= */

    private static double ease(double x) {
        return x * x * (3 - 2 * x);
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static Particle fireworkParticle() {
        try {
            return Particle.valueOf("FIREWORK");          // 1.20.5+
        } catch (IllegalArgumentException ex) {
            try {
                return Particle.valueOf("FIREWORKS_SPARK"); // 1.20.1 - 1.20.4
            } catch (IllegalArgumentException ex2) {
                return Particle.END_ROD;
            }
        }
    }

    /* ================= sesi sinematik ================= */

    final class Session implements Runnable {
        final Player p;
        final Type type;
        final Location origin;

        Location ground;
        float bodyYaw;
        ArmorStand cam;
        List<Entity> body = new ArrayList<>();
        BukkitTask task;
        int t = 0;
        double startAng;

        Session(Player p, Type type, Location origin) {
            this.p = p;
            this.type = type;
            this.origin = origin;
        }

        void start() {
            if (type == Type.REVIVE) p.teleport(origin);   // muat chunk lebih dulu
            p.setGameMode(GameMode.SPECTATOR);

            ground = findGround(type == Type.REVIVE ? origin : p.getLocation());
            bodyYaw = Math.round(origin.getYaw() / 90f) * 90f;
            startAng = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);

            body = spawnBody(p, ground, bodyYaw);
            if (type == Type.FAINT) {
                removeCorpse(p.getUniqueId());
                corpses.put(p.getUniqueId(), body);
            }

            cam = ground.getWorld().spawn(camLocation(0), ArmorStand.class, a -> {
                a.setInvisible(true);
                a.setMarker(true);
                a.setGravity(false);
                a.setInvulnerable(true);
                a.setSilent(true);
                a.setPersistent(false);
            });

            if (type == Type.REVIVE) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 50, 0, false, false, false));
            } else {
                ground.getWorld().playSound(ground, Sound.ENTITY_PLAYER_HURT, 1f, 0.6f);
            }
            task = Bukkit.getScheduler().runTaskTimer(plugin, this, 1L, 1L);
        }

        private int total() {
            return type == Type.FAINT ? FAINT_TICKS : REVIVE_TICKS;
        }

        private Location camLocation(int tick) {
            double prog = Math.min(1.0, tick / (double) total());
            double e = ease(prog);
            double r, h, ang;
            if (type == Type.FAINT) {
                r = lerp(3.2, 1.7, e);
                h = lerp(1.9, 0.8, e);
                ang = startAng + e * Math.PI * 0.6;
            } else {
                r = lerp(1.7, 3.4, e);
                h = lerp(0.8, 2.2, e);
                ang = startAng - e * Math.PI * 0.5;
            }
            World w = ground.getWorld();
            Location center = ground.clone().add(0, 0.3, 0);
            Vector off = new Vector(Math.cos(ang) * r, h, Math.sin(ang) * r);

            // jangan tembus blok
            RayTraceResult hit = w.rayTraceBlocks(center, off.clone().normalize(), off.length(),
                    FluidCollisionMode.NEVER, true);
            if (hit != null && hit.getHitPosition() != null) {
                double dist = Math.max(0.4, hit.getHitPosition().distance(center.toVector()) - 0.3);
                off = off.clone().normalize().multiply(dist);
            }

            Location eye = center.clone().add(off);
            Vector dir = center.toVector().subtract(eye.toVector());
            double eyeH = (cam != null) ? cam.getEyeHeight() : 0.0;
            Location loc = eye.clone().subtract(0, eyeH, 0);
            loc.setDirection(dir);
            return loc;
        }

        private void glitter(int count, double radius, double height) {
            World w = ground.getWorld();
            Location c = ground.clone().add(0, height, 0);
            w.spawnParticle(Particle.END_ROD, c, count, radius, 0.4, radius, 0.01);
        }

        @Override
        public void run() {
            if (!p.isOnline() || cam == null || !cam.isValid()) {
                sessions.remove(p.getUniqueId());
                cleanup();
                return;
            }
            t++;

            // pastikan tetap melihat lewat kamera (shift = keluar spectate)
            Entity tgt = p.getSpectatorTarget();
            if (tgt == null || !tgt.getUniqueId().equals(cam.getUniqueId())) p.setSpectatorTarget(cam);
            cam.teleport(camLocation(t));

            World w = ground.getWorld();
            if (type == Type.FAINT) {
                if (t % 5 == 0) glitter(3, 0.5, 0.5);
                if (t == 40) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 120, 0, false, false, false));
                }
                if (t == 60) {
                    w.playSound(ground, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 0.7f);
                    p.showTitle(Title.title(
                            Component.text("PINGSAN", NamedTextColor.DARK_RED, TextDecoration.BOLD),
                            Component.text("Kamu akan bangkit kembali...", NamedTextColor.GRAY),
                            Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofSeconds(1))));
                }
                if (t >= FAINT_TICKS) finishFaint();
            } else {
                if (t % 4 == 0) glitter(2, 0.5, 0.5);
                if (t == 20) w.playSound(ground, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
                if (t == 75) {
                    w.playSound(ground, Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.4f);
                    w.spawnParticle(fireworkParticle(), ground.clone().add(0, 0.5, 0), 30, 0.5, 0.4, 0.5, 0.05);
                }
                if (t == 90) {
                    removeAll(body);
                    body = new ArrayList<>();
                    w.spawnParticle(Particle.SOUL, ground.clone().add(0, 0.5, 0), 20, 0.4, 0.4, 0.4, 0.02);
                }
                if (t >= REVIVE_TICKS) finishRevive();
            }
        }

        private void finishFaint() {
            sessions.remove(p.getUniqueId());
            cleanup();
            reapplyWaiting(p);
        }

        private void finishRevive() {
            sessions.remove(p.getUniqueId());
            cleanup();
            Location land = ground.clone().add(0, 0.1, 0);
            land.setYaw(origin.getYaw());
            completeRevive(p, land);
        }

        /** Hentikan task, hapus kamera. Badan pingsan (FAINT) dibiarkan sebagai mayat. */
        void cleanup() {
            if (task != null) {
                task.cancel();
                task = null;
            }
            if (cam != null && cam.isValid()) cam.remove();
            if (type == Type.REVIVE) {
                removeAll(body);
                body = new ArrayList<>();
            }
        }
    }
}
