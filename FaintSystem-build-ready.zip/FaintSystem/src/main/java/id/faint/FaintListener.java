package id.faint;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public final class FaintListener implements Listener {

    private final FaintPlugin plugin;
    private final FaintManager mgr;

    public FaintListener(FaintPlugin plugin, FaintManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    private boolean hasTotem(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    /* ---------- pingsan saat damage mematikan ---------- */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e instanceof EntityDamageByEntityEvent be
                && be.getDamager() instanceof Player damager
                && mgr.isRestricted(damager)) {
            e.setCancelled(true);
            return;
        }
        if (!(e.getEntity() instanceof Player p)) return;

        if (mgr.isRestricted(p)) {
            e.setCancelled(true);
            return;
        }
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        if (hasTotem(p)) return; // totem vanilla jalan seperti biasa

        e.setCancelled(true);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) mgr.startFaint(p);
        });
    }

    /* ---------- jalur cadangan: mati beneran (mis. setHealth(0) dari plugin lain) ---------- */

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        mgr.markDeath(p);
        if (!plugin.getConfig().getBoolean("drop-inventory-on-faint", false)) {
            e.setKeepInventory(true);
            e.getDrops().clear();
        }
        e.setKeepLevel(true);
        e.setDroppedExp(0);
        e.deathMessage(null);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (!mgr.isDead(p)) return;
        Location s = mgr.deadSpawn();
        if (s != null) e.setRespawnLocation(s);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) mgr.reapplyWaiting(p);
        });
    }

    /* ---------- pembatasan saat pingsan / mati ---------- */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!mgr.isRestricted(p) || p.hasPermission("faint.bypass")) return;

        String label = e.getMessage();
        if (label.startsWith("/")) label = label.substring(1);
        int sp = label.indexOf(' ');
        if (sp >= 0) label = label.substring(0, sp);
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        label = label.toLowerCase();

        for (String a : mgr.allowedCommands()) {
            if (a.equalsIgnoreCase(label)) return;
        }
        e.setCancelled(true);
        p.sendMessage(Component.text("Kamu tidak bisa memakai command saat sedang mati.", NamedTextColor.RED));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!mgr.isWaiting(p)) return;
        int r = mgr.waitRadius();
        Location spawn = mgr.deadSpawn();
        Location to = e.getTo();
        if (r <= 0 || spawn == null || to == null || spawn.getWorld() == null) return;

        double rr = (double) r * r;
        boolean toOut = !spawn.getWorld().equals(to.getWorld()) || to.distanceSquared(spawn) > rr;
        if (!toOut) return;

        Location from = e.getFrom();
        boolean fromIn = spawn.getWorld().equals(from.getWorld()) && from.distanceSquared(spawn) <= rr;
        if (fromIn) {
            e.setCancelled(true);
        } else {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (p.isOnline() && mgr.isWaiting(p)) p.teleport(spawn);
            });
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE && mgr.isRestricted(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (mgr.isRestricted(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (mgr.isRestricted(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (mgr.isRestricted(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (mgr.isRestricted(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (mgr.isRestricted(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && mgr.isRestricted(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && mgr.isRestricted(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent e) {
        if (e.getTarget() instanceof Player p && mgr.isRestricted(p)) e.setCancelled(true);
    }

    /* ---------- login / logout ---------- */

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) mgr.onJoin(p);
        }, 5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        mgr.onQuit(e.getPlayer());
    }
}
