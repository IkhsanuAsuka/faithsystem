FaintSystem 1.0.0 (tulis ulang) - Paper 1.20.1 s/d 1.21.1

BUILD
  Butuh JDK 17/21 + Maven.
  mvn clean package
  Hasil: target/FaintSystem-1_0_0.jar -> taruh di folder plugins/

CATATAN
  - Khusus Paper (bukan Spigot murni).
  - Target bytecode Java 17 (jalan di Java 17 dan 21). Mau khusus 21:
    ubah <maven.compiler.release> di pom.xml jadi 21.
  - Badan pingsan memakai display entity (kepala skin pemain + blok),
    karena entity Mannequin baru ada di 1.21.9+.
  - Data (lokasi /setspawndead & daftar pemain mati) tersimpan di plugins/FaintSystem/data.yml
